# BOOK-001 — Reserve an available resource

Status: Draft / illustrative
Owner: To be assigned

## Outcome and actor

A signed-in member reserves an available resource and receives a confirmation.

## Scope

Include availability, confirmation, capacity conflicts, and same-request replay.
Defer payments, recurring reservations, and real notifications.

## Preconditions and state model

Define the authorized actor, resource boundary, slot state, permitted transitions, and input rules before implementation.

## Proposed acceptance criteria

| ID | Expected outcome | Verification |
| --- | --- | --- |
| AC-BOOK-01 | An authorized valid request creates one confirmed reservation. | API/database integration |
| AC-BOOK-02 | Competing requests never exceed approved capacity. | Database-backed concurrency |
| AC-BOOK-03 | Same-key replay returns the original booking without a duplicate. | Idempotency integration |
| AC-BOOK-04 | An unauthorized actor receives no protected booking data. | Authorization negative cases |

## Failure and recovery behavior

Define recovery after a network loss with an uncertain commit outcome. Specify user messages and retained inputs if a UI is in scope.

## Open decisions

| Decision | Owner | Resolution |
| --- | --- | --- |
| Capacity and slot model | Product + Engineering | Pending |
| Actor/resource permissions | Product + Security | Pending |
| Idempotency scope, expiry, payload mismatch | Engineering + Product | Pending |
| Unauthorized response policy | Security + Engineering | Pending |
| Measurable quality targets | Product + Engineering | Pending |

## Traceability and review

Link technical-spec.md, handoff.md, implementation changes, and qa-report.md.
Record the actual scope decision, date, and owner when made.
