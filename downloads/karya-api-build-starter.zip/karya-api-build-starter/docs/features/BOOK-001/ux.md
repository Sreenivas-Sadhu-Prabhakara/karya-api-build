# BOOK-001 — Interaction notes

Status: Draft; use only if an interface is in scope.

## Entry and preconditions

Document how the user reaches the feature and the required permissions.

## States

- Loading and empty availability.
- Slot selection and submission.
- Confirmed reservation.
- Capacity conflict.
- Unauthorized or expired session.
- Network failure and uncertain result recovery.

## Accessibility and recovery

Define labels, focus behavior, keyboard operation, error announcements, retained inputs, and deliberate retry behavior.
