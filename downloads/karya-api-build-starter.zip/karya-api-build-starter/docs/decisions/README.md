# Architecture decisions

For each material decision, record context, considered options, the actual decision, owner/date, consequences, and affected feature IDs. Clearly label proposals and superseded decisions.
