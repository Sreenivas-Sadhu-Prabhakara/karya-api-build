# karya-api-build starter kit

Use this kit for one bounded API feature in your own repository. Review and adapt the draft templates before implementation. Keep your repository's existing IDs and artifact locations when available.

1. Start with the included guide and select one useful outcome.
2. Adapt CLAUDE.md to actual repository paths and commands.
3. Review spec.md, clarify decisions, and plan the technical approach.
4. Authorize bounded implementation tasks in handoff.md.
5. Implement and verify; record actual results in qa-report.md.

The BOOK-001 example is synthetic and illustrative. No code, executed tests, product approval, or production authorization is implied. These templates do not select a framework or cloud provider.
