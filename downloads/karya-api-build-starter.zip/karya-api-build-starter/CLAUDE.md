# karya-api-build working agreement

- Read the selected feature specification and relevant decisions before implementing.
- Feature artifacts live in docs/features/<FEATURE-ID>/; adapt to existing repository conventions.
- Reuse existing feature and acceptance IDs.
- Keep proposals separate from agreed decisions.
- Work in small, bounded, authorized increments.
- Link acceptance criteria to meaningful verification.
- Use synthetic development and test data.
- Report actual results as PASS, FAIL, NOT_RUN, or BLOCKED.
- Update affected specifications when behavior changes.
- Preserve unrelated user work.

## Repository commands

Discover build, test, lint, and development commands from the actual repository. Record verified commands here. No commands have been verified by this template.

## Sources and decisions

Link the actual product brief and architecture decisions here. Import @AGENTS.md only if the file exists and is relevant.
